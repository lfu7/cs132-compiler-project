package Support;

public class LivenessWrapper {
    public String varName;
    public LivenessInterval li;
}