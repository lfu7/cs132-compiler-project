package Support;

public class LivenessInterval {
    public int def;
    public int use;
}